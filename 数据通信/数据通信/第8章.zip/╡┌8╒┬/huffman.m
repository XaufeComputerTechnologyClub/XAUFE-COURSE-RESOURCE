function [h,l]=huffman(p)
if length(find(p<0))~=0;      %�ж������Ƿ���ʷֲ�
    error('Input is not a prob.vector, there is negative component');
end
if abs(sum(p)-1)>10e-10
    error('Input is not a prob.vector,the sum of the component is not equal to 1.');
end
n=length(p);  %�õ������Ԫ�ظ���
q=p;
m=zeros(n-1,n);
for i=1:n-1,
    [q,e]=sort(q);
    m(i,:)=[e(1:n-i+1),zeros(1,i-1)];
    q=[q(1)+q(2)+q(3:n),e];
end
for i=1:n-1,
    c(i,:)=blanks(n*n);
end
%���¼������Ԫ������
c(n-1,n)='0';
c(n-2,2*n)='1';
for i=2:n-1
    c(n-i,1:n-1)=c(n-i+1,n*(find(m(n-i+1,:)==1))-(n-2):n*(find(m(n-i+1,:)==1)));
    c(n-i,n)='0';
    c(n-i,n+1:2*n-1)=c(n-i,1:n-1);
    c(n-i,2*n)='1';
    for j=1:i-1
        c(n-i,(j+1)*n+1:(j+2)*n)=c(n-i+1,n*(find(m(n-i+1,:)==j+1)-1)+...
1:n*find(m(n-i+1,:)==j+1));
    end
end
for i=1:n
    h(i,1:m)=c(1,n*(find(m(1,:)==i)-1)+1:find(m(1,:)==i)*n);
    e(i)=length(find(abs(h(i,:))~=32));
end
e=sum(p.*e);  %����ƽ���볤
